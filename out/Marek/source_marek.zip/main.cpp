#include <bits/stdc++.h>
#include "common.hpp"

using namespace std;

const int NEIGHBOURS = 30;

using Pics = vector<Picture>;

void splitPictures(const Pics &pics, Pics &vertical, Pics &horizontal)
{
    for (const auto &val : pics)
    {
        if (val.paired)
            vertical.push_back(val);
        else
            horizontal.push_back(val);
    }
}

Slideshow slideshow;
vector<Slide> slides;
vector<bool> used;

int rnd(int a, int b)
{
    return (rand() % (b - a + 1)) + a;
}

int main()
{
    vector<Picture> pictures = readPictures();
    Pics hori, vert;
    splitPictures(pictures, vert, hori);

    // random_shuffle(vert.begin(), vert.end());

    for (int i = 0; (2 * i) + 1 < int(vert.size()); i++)
    {
        Slide slide(vert[i + i], vert[i + i + 1]);
        slides.push_back(slide);
        used.push_back(false);
    }

    for (auto &val : hori)
    {
        Slide slide(val);
        slides.push_back(slide);
        used.push_back(false);
    }

    // for (auto val:slides)
    //   cerr<<val.first.id<<endl;
    //   cerr<<endl;
//    random_shuffle(slides.begin(), slides.end());
    // for (auto val:slides)
    //   cerr<<val.first.id<<endl;

    int poz = 0;
    int pop = 0;
    slideshow.show.push_back(slides[poz]);

    for (int i = 0; i < int(slides.size()) - 1; i++)
    {
        int maxi = -1;
        int num;
        used[poz] = true;

        for (int j = 0; j < NEIGHBOURS; j++)
        {
            int index = rnd(0, int(slides.size()) - 1);

            if (used[index])
              continue;

            if (maxi < slides[poz] + slides[index])
            {
                maxi = slides[poz] + slides[index];
                num = index;
            }
        }

        if (maxi == -1)
        {
            for(int j = pop; j < int(slides.size()); j++)
            {
                if (used[j])
                {
                    pop = j + 1;
                    continue;
                }

                num = j;
                break;
            }
        }

        used[num] = true;
        slideshow.show.push_back(slides[num]);

        poz = num;
        if (i % 1000 == 0)
          cerr<<poz<<" "<<i<<endl;
    }

    slideshow.print();

    return 0;
}
